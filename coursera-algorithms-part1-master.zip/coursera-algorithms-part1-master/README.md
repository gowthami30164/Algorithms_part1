# What this repository is about?
My solutions to the course "Algorithms, Part I"
