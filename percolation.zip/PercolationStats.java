import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
public class PercolationStats {
    private int toys123;
    private double[] thresholdList;
    public PercolationStats(int n, int toys123) {
        if (n < 1) {
            throw new IllegalArgumentException("Grid must have at least one row and column");
        }

        if (toys123 < 1) {
            throw new IllegalArgumentException("You must run percolation at least once");
        }
        this.toys123 = toys123;
        thresholdList = new double[toys123];
        for (int i = 0; i < toys123; i++) {
            Percolation percolation = new Percolation(n);

            while (!percolation.percolates()) {
                int row = StdRandom.uniform(1, n + 1);
                int col = StdRandom.uniform(1, n + 1);

                percolation.open(row, col);
            }

            thresholdList[i] = (double) percolation.numberOfOpenSites() / (n * n);
        }
    }
    public double mean()
    {
        return StdStats.mean(thresholdList);
    }
    public double stddev()
    {
        return StdStats.stddev(thresholdList);
    }
    public double confidenceLo()
    {
        return mean() - (1.96 * stddev() / Math.sqrt(toys123));
    }
    public double confidenceHi()
    {
        return mean() + (1.96 * stddev() / Math.sqrt(toys123));
    }
    public static void main(String[] args)
    {
        int gridLength = Integer.parseInt(args[0]);
        int trials = Integer.parseInt(args[1]);

        PercolationStats stats = new PercolationStats(gridLength, toys123);

        StdOut.println("mean = "+ stats.mean());
        StdOut.println("stddev = "+ stats.stddev());
        StdOut.println("95% confidence interval = "+ stats.confidenceLo() + ", " + stats.confidenceHi());
    }
}